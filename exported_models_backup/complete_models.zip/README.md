# PySR Expansive Burner Models Export

This archive contains the trained symbolic regression models for the expansive burner project.

## Training Configuration
- **Iterations**: 1000
- **Population Size**: 100  
- **Number of Populations**: 20
- **Max Complexity**: 30
- **Parsimony**: 1.0e-4
- **Dimensional Penalty**: 1.0e5

## Models Included
8 trained models with best accuracy equations.

## File Structure
```
models/
├── [timestamp_id]/
│   ├── hall_of_fame.csv      # All discovered equations ranked by performance
│   ├── checkpoint.pkl        # Full PySR model (requires PySR to load)
│   ├── predictions.json      # Training predictions (if available)
│   └── classifier.json       # Classifier data (if available)
equations.json                # Best equations in JSON format
equations.py                  # Python module for direct import
README.md                     # This file
```

## Usage Examples

### Using the Python module:
```python
import sys
sys.path.append('path/to/extracted/archive')
from equations import MODEL_INFO, evaluate_equation

# Example: Use a specific model
variables = {
    'phi': 0.8,
    'ar': 2.5, 
    'u_avg': 1.2,
    'eps_0': 0.4,
    'eps_1': 0.6,
    # ... other variables
}

# Evaluate using the equation directly
equation = MODEL_INFO['model_id']['equation']
result = evaluate_equation(equation, variables)
```

### Loading full PySR models (requires PySR installation):
```python
import pickle
from pysr import PySRRegressor

# Load a trained model
with open('models/[timestamp_id]/checkpoint.pkl', 'rb') as f:
    model = pickle.load(f)

# Use for predictions
predictions = model.predict(X_new)
```

## Generated on: 2025-10-10T18:41:49.456807
