"""
Auto-generated equations from PySR training
============================================

This module contains the best discovered equations from symbolic regression.
Each function implements the best-accuracy model for its respective target.

Generated on: 2025-10-10T18:41:49.456647
Source: sr_expansive_burner multi-target training
Training config: 1000 iterations, 100 population_size, 30 maxsize, 1e-4 parsimony
"""

import numpy as np
from typing import Union, Dict, Any

# Model metadata
MODEL_INFO = {
    "20251010_163632_gWjNbU": {
        "equation": "0.7091164",
        "complexity": 1,
        "loss": 0.15781274,
        "model_type": "no_flame_surrogate",
        "target_variable": "outlet_velocity"
    }
}

def evaluate_equation(equation_str: str, variables: Dict[str, float]) -> float:
    """
    Safely evaluate a PySR equation string with given variables.
    
    Args:
        equation_str: The equation string from PySR
        variables: Dictionary mapping variable names to values
    
    Returns:
        The evaluated result
    """
    # Replace common PySR functions with numpy equivalents
    equation_str = equation_str.replace("sqrt", "np.sqrt")
    equation_str = equation_str.replace("log", "np.log")
    equation_str = equation_str.replace("exp", "np.exp")
    equation_str = equation_str.replace("abs", "np.abs")
    
    # Create a safe namespace for evaluation
    namespace = {"np": np, "__builtins__": {}}
    namespace.update(variables)
    
    try:
        return eval(equation_str, namespace)
    except Exception as e:
        raise ValueError(f"Error evaluating equation '{equation_str}': {e}")


def predict_outlet_velocity_gWjNbU(variables: Dict[str, float]) -> float:
    """
    Predict outlet_velocity using no_flame_surrogate model.
    
    Target Variable: outlet_velocity
    Equation: 0.7091164
    Complexity: 1
    Loss: 1.578127e-01
    
    Args:
        variables: Dict with keys like {'phi', 'ar', 'u_avg', 'eps_0', 'eps_1', ...}
    
    Returns:
        Predicted outlet_velocity
    """
    equation = "0.7091164"
    return evaluate_equation(equation, variables)
